// Escena básica
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

// Cámara desde arriba
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  2000
);
camera.position.set(0, 600, 0);
camera.lookAt(0, 0, 0);

// Renderizador
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Luz principal 
const luz = new THREE.PointLight(0xffffff, 3, 3000);
luz.position.set(0, 0, 0);
scene.add(luz);

// Sol 
const materialSol = new THREE.MeshBasicMaterial({ color: 0xffff00 });
const sol = new THREE.Mesh(new THREE.SphereGeometry(30, 32, 32), materialSol);
scene.add(sol);

// Clase para planetas con luna
class Planeta {
  constructor(distancia, radio, color, velocidad, colorLuna) {
    this.grupo = new THREE.Group();

    // Planeta simple y colorido
    const geometriaPlaneta = new THREE.SphereGeometry(radio, 24, 24);
    const materialPlaneta = new THREE.MeshBasicMaterial({ color: color });
    this.planeta = new THREE.Mesh(geometriaPlaneta, materialPlaneta);
    this.planeta.position.x = distancia;
    this.grupo.add(this.planeta);

    // Luna
    const geometriaLuna = new THREE.SphereGeometry(radio / 2.5, 12, 12);
    const materialLuna = new THREE.MeshBasicMaterial({ color: colorLuna });
    this.luna = new THREE.Mesh(geometriaLuna, materialLuna);
    this.luna.position.x = radio * 2;
    this.planeta.add(this.luna);

    this.velocidad = velocidad;
    this.angulo = Math.random() * Math.PI * 2;

    scene.add(this.grupo);
  }

  actualizar() {
    this.angulo += this.velocidad;
    this.grupo.rotation.y = this.angulo;
  }
}

// Planetas 
const planetas = [
  new Planeta(70, 7, 0xff3333, 0.025, 0xffffff),
  new Planeta(110, 8, 0xff9900, 0.020, 0xffffff),
  new Planeta(150, 9, 0x00aaff, 0.018, 0xffffff),
  new Planeta(190, 10, 0x00ff66, 0.015, 0xffffff),
  new Planeta(240, 11, 0xff00ff, 0.012, 0xffffff),
  new Planeta(300, 12, 0x33ffcc, 0.010, 0xffffff),
  new Planeta(370, 13, 0xffff33, 0.008, 0xffffff),
  new Planeta(450, 14, 0x4488ff, 0.006, 0xffffff)
];

// Animación
function animar() {
  requestAnimationFrame(animar);
  sol.rotation.y += 0.002;
  planetas.forEach(p => p.actualizar());
  renderer.render(scene, camera);
}
animar();

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
